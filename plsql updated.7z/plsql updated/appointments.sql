create table APPOINTMENTS
(
  appointment_id NUMBER generated always as identity,
  doctor_id      NUMBER not null,
  patient_id     NUMBER not null,
  start_time     TIMESTAMP(6) not null,
  end_time       as ("START_TIME"+INTERVAL'+00 01:00:00' DAY(2) TO SECOND(0)),
  notes          VARCHAR2(1000),
  isbooked       NUMBER default 1,
  userid         NUMBER
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column APPOINTMENTS.isbooked
  is '1-booked, 0-free';
alter table APPOINTMENTS
  add primary key (APPOINTMENT_ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table APPOINTMENTS
  add constraint FK_APPOINTMENTS_DOCTOR_ID foreign key (DOCTOR_ID)
  references DOCTORS (ID);
alter table APPOINTMENTS
  add constraint FK_APPOINTMENTS_PATIENT_ID foreign key (PATIENT_ID)
  references USERS (ID);
alter table APPOINTMENTS
  add constraint FK_APPOINTMENTS_USERID foreign key (USERID)
  references USERS (ID);
