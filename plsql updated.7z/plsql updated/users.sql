create table USERS
(
  id            NUMBER generated always as identity,
  fname         VARCHAR2(100),
  lname         VARCHAR2(100),
  idnumber      VARCHAR2(100),
  email         VARCHAR2(100),
  password      VARCHAR2(100),
  discriminator VARCHAR2(100) not null,
  imageurl      VARCHAR2(100)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
comment on column USERS.discriminator
  is 'Doctor or Patient';
alter table USERS
  add constraint PK_USERS_ID primary key (ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table USERS
  add constraint EMAIL unique (EMAIL)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
