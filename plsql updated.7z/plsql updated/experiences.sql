create table EXPERIENCES
(
  experience_id NUMBER not null,
  doctor_id     NUMBER not null,
  company_name  VARCHAR2(255),
  role          VARCHAR2(255),
  start_date    DATE,
  end_date      DATE,
  description   VARCHAR2(4000)
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table EXPERIENCES
  add primary key (EXPERIENCE_ID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table EXPERIENCES
  add constraint FK_DOCTOR_ID foreign key (DOCTOR_ID)
  references DOCTORS (ID);
