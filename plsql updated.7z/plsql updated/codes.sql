create table ACTIVATION_CODES
(
  codeid         NUMBER generated always as identity,
  useremail      VARCHAR2(100) not null,
  activationcode VARCHAR2(255),
  generatedtime  TIMESTAMP(6) default SYSTIMESTAMP not null,
  expirationtime TIMESTAMP(6) default (SYSTIMESTAMP + INTERVAL '30' MINUTE) not null,
  isvalid        NUMBER default 0
)
tablespace USERS
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table ACTIVATION_CODES
  add constraint PK_ACTIVATION_CODES_CODEID primary key (CODEID)
  using index 
  tablespace USERS
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
